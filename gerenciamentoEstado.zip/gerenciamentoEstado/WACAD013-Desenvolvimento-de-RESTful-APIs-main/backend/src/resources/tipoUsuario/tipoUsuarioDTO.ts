export enum TipoUsuario {
   ADMIN="ADMIN"
}