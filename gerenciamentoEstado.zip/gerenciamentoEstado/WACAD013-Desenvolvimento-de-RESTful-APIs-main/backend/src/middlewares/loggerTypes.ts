export type Tipo = 'completo' | 'simples';
