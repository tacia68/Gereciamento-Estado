# Web Academy
## Esqueleto de aplicação com backend Express e frontend React.

Para rodar a aplicação, execute os seguintes comandos:

```
$ cp .env.example .env
$ cp frontend/.env.example frontend/.env
$ cp backend/.env.example backend/.env
$ cd frontend && npm install && cd ..
$ cd backend && npm install && cd ..
$ docker compose run
