import React, { useEffect, useReducer } from 'react';
import logo from './logo.svg';
import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from './redux/store';
import { increment, decrement, quadrado } from './redux/features/count.slide';
import ListagemProdutos from "./components/listProdutos";
import FormularioProduto from './components/formProduto';
import { fetchProdutos } from './redux/features/produto.slice';

// App.tsx
// App.tsx
/*import "./App.css";

import { increment } from "./redux/features/count.slice";

// npx create-react-app redux_teste --template typescript*/

function App() {
  const dispach = useDispatch<AppDispatch>();

  useEffect(() =>{
    dispach(fetchProdutos());
  })


  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        flexDirection: "column",
        alignItems: "center",
        justifyItems: "center",
      }}
      
    >

      <div>
        <FormularioProduto/>
      </div>

      
      <div style={{ width: "50%" }}>
        <ListagemProdutos />
      </div>
    </div>
  );
}


/*
  //segunda parte

  const dispach = useDispatch();
  const count = useSelector((state: RootState) => state.count);

  return (
    <div className='App'>
      <p> {count.value}</p>
      <button onClick={() => dispach(increment())}> +1</button>
      <button onClick={() => dispach(decrement())}> -1</button>
      <button onClick={() => dispach(quadrado())}> quadrado</button>
    </div>
  )

  //fim segunda parte
  */

  /*function reducer(state: any, action:any){
    switch(action.type){
      case 'ADD': 
        return {count: state.count +1};
      case 'ADD10':
        return {count: state.count + 10}
      case 'SUB':
        return {count: state.count - 1}
      case 'SUB10':
        return {count: state.count - 10}
      case 'RESET':
        return {count:0}
    }
  }

  const[state, dispatc] = useReducer(reducer, {count:0});
  return (
    <div className="App">
      <p>Count: {state?.count}</p>

      <div>
        <button onClick={() => dispatc({type: "ADD"})}>Add + 1</button>
        <button onClick={() => dispatc({type: "ADD10"})}>Add + 10</button>
        <button onClick={() => dispatc({type: "SUB"})}>Delete - 1</button>
        <button onClick={() => dispatc({type: "SUB10"})}>Delete - 10</button>
        <button onClick={() => dispatc({type: "RESET"})}>Reset</button>
      </div>
    </div>
    
  );
*/


export default App;
