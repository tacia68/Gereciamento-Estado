import { createSlice } from "@reduxjs/toolkit";

export const countSlice = createSlice({
    name: "counterSlice",
    initialState: {
        value:0,
    },

    reducers: {
        increment(state){
            state.value += 1;
        },
        decrement(state){
            state.value -= 1
        },
        quadrado(state){
            state.value = state.value * state.value
        },
    },
});

export const {increment, decrement, quadrado} = countSlice.actions;
export default countSlice.reducer